# Caleb Wallet

A Vercel-ready React/Vite frontend for Caleb Wallet.

## Deploy
1. Upload the contents of this folder to the root of a new GitHub repository.
2. Import the repository into Vercel.
3. Use framework preset **Vite**, build command `npm run build`, output directory `dist`.

## Important before launch
This package is a frontend interface only. It does not create real wallets, hold crypto, verify deposits, store accounts, or process withdrawals. Before accepting users or funds, implement:
- Server-side authentication, database, role-based admin access and account recovery.
- A reputable wallet/custody or payment provider and verified TRON/TRC20 deposit monitoring.
- Server-side balance ledger, withdrawal queue, admin approval, audit logs and anti-fraud checks.
- HTTPS, rate limiting, backups, privacy notice, consent and account deletion.
- Security and legal/compliance review.

Never ask users for seed phrases or private keys. Never place wallet secrets or API keys in frontend code. Do not show fabricated balances or claim mining is occurring.
